package com.edu.student;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class StudentDataOperations {
	static Connection scon=null;
	static ResultSet rs=null;
	static Statement st=null;

	static Scanner sc=new Scanner(System.in);
	static int sid;
	static String sname;
	static String scourse;

	public static void insertStudentInfo() {

		try {
			scon=DbConnect.getConnection();
			st=scon.createStatement();
			System.out.println("My Connection"+scon);

			//get input from user
			System.out.println("Enter the ID od the student");
			sid=sc.nextInt();
			//check id exist
			String sql="select * from edustudent where sid="+sid;
			rs=st.executeQuery(sql);

			if(!rs.next())
			{
				System.out.println("Enter student name");
				sname=sc.next();
				System.out.println("Enter student Course name");
				scourse=sc.next();

				String ins="insert into edustudent values("+sid+",'"+sname+"','"+scourse+"')";
				int  i =st.executeUpdate(ins);
				if(i>0)
				{
					System.out.println("Student information is registered");
				}
			}
			else 
			{
				System.out.println("Id already exists Choose another id");
			}
		} 
		catch (SQLException e)
		{

			e.printStackTrace();
		}


	}

	public static void updateStudentInfo() {
		// connection
		try
		{
			scon=DbConnect.getConnection();
			st=scon.createStatement();
			System.out.println("Enter the student id to be update");
			sid=sc.nextInt();
			String sql="select * from edustudent where sid="+sid;
			rs=st.executeQuery(sql);
			if(rs.next()) 
			{
				System.out.println("What do you want to update");
				System.out.println("1.Name\n2.Course\n3.Both Name and course");
				int ch=sc.nextInt();
				if(ch==1) 
				{
					System.out.println("Enter Name to change");
					sname=sc.next();
					String upd="update edustudent set sname='"+sname+"' where sid="+sid;
					int i=st.executeUpdate(upd);
					if(i>0)
					{
						System.out.println("Name Updated successfully");
					}
				}
				if(ch==2) 
				{
					System.out.println("Enter Course Name to change");
					scourse=sc.next();
					String updc="update edustudent set scourse='"+scourse+"' where sid="+sid;
					int j=st.executeUpdate(updc);
					if(j>0)
					{
						System.out.println("Course name updated successfully");
					}
				}
				if(ch==3)
				{
					System.out.println("Enter Name to change");
					sname=sc.next();
					System.out.println("Enter Course Name to change");
					scourse=sc.next();
					String updname="update edustudent set sname='"+sname+"',scourse='"+scourse+"' where sid="+sid;
					int i=st.executeUpdate(updname);
					if(i>0)
					{
					System.out.println("Name and Course Name updated successfully");
					}
				}

			}
			else
			{
				System.out.println("ID is not found");
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public static void deleteStudentInfo() {
		try
		{
		scon=DbConnect.getConnection();
		st=scon.createStatement();
		System.out.println("Enter the Id to Delete the record");
		int sid=sc.nextInt();
		String sql="select * from edustudent where sid="+sid;
		rs=st.executeQuery(sql);
		if(rs.next())
		{
			String del="Delete from edustudent where sid="+sid;
			int i=st.executeUpdate(del);
			if(i>0)
			{
				System.out.println(sid+" Record is deleted Successfully");
			}
			}
		else 
			{
			System.out.println("Id"+sid+" is not exist");	
			}
		System.out.println();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void selectStudentInfo() {
		try
		{
			scon=DbConnect.getConnection();
			st=scon.createStatement();
			System.out.println("Enter the Student id");
			int sid=sc.nextInt();
			String sql="select * from edustudent where sid="+sid;
			rs=st.executeQuery(sql);
			System.out.println("ID\tNAME\tCOURSENAME");
			if(rs.next()) {
				System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3));
			}
			else
			{
				System.out.println(sid+ "id is not exist Please Enter Valid Id");
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}
	public static void displayStudentInfo() {
		try {
			//get connection
			scon=DbConnect.getConnection();
			st=scon.createStatement();

			String sql="select * from edustudent";
			rs=st.executeQuery(sql);

			System.out.println("ID\tNAME\tCOURSENAME");
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3));
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}

	}
}
