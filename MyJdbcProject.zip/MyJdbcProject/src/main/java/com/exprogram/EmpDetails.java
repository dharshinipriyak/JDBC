package com.exprogram;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class EmpDetails {

	public static void main(String[] args) {
	String mytable="create table empdetails(id int(4) primary key,name varchar(30))";
		
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/dkdatabase";
		String user="root";
		String password="root";
		
		try {
		Class.forName(driver);
		Connection conn=DriverManager.getConnection(url, user, password);
		Statement st=conn.createStatement();
		st.execute(mytable);
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
