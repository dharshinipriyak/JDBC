package com.exprogram;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class InsertTheRecord {

	public static void main(String[] args) {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/dkdatabase";
		String user="root";
		String password="root";
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter id to insert into the record");
		int id=sc.nextInt();
		String sql="select * from empdetails where id="+id;
		try {
			Class.forName(driver);
			conn =DriverManager.getConnection(url, user, password);
			st=conn.createStatement();
			
			rs=st.executeQuery(sql);
			if(!rs.next())
			{
				System.out.println("Enter the name to be inserted");
				String name=sc.next();
				String insert="insert into empdetails values("+id+",'"+name+"')";
				int i=st.executeUpdate(insert);
				if(i>0) {
					System.out.println("Record is inserted successfully");
				}
			}
			else {
				System.out.println("Id is already exist");
			}
			

	}
	catch (Exception e) {
		e.printStackTrace();
	}
sc.close();
	}

}
