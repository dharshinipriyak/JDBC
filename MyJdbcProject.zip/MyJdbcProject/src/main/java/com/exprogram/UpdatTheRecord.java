package com.exprogram;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class UpdatTheRecord {

	public static void main(String[] args) {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/dkdatabase";
		String user="root";
		String password="root";
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter id to update");
		int id=sc.nextInt();
		
		try {
			Class.forName(driver);
			conn =DriverManager.getConnection(url, user, password);
			st=conn.createStatement();
			String sql="select * from empdetails where id="+id;
			rs=st.executeQuery(sql);
			//check id exist
			if(rs.next())
			{ 
				System.out.println("Enter Name to change");
				String name=sc.next();
				String upd="update empdetails set name='"+name+"' where id="+id;
				int i=st.executeUpdate(upd);
				if(i>0) {
					System.out.println("Record is updated successfully");
				}
			}
			else {
				System.out.println("Record not found");
			}
			

	}
	catch (Exception e) {
		e.printStackTrace();
	}
sc.close();
	}

}
