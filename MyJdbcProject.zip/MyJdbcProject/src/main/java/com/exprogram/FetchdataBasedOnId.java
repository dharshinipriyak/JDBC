package com.exprogram;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class FetchdataBasedOnId {

	public static void main(String[] args) {
		//connection
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/dkdatabase";
		String user="root";
		String password="root";
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter name to fetch record");
		String name=sc.next();

		try {
			Class.forName(driver);
			conn =DriverManager.getConnection(url, user, password);
			st=conn.createStatement();
			String sql="select * from empdetails where name='"+name+"'";
			rs=st.executeQuery(sql);
			if(rs.next())
			{
				System.out.println("Id="+rs.getInt(1)+" Name ="+rs.getString(2));
			} else
			{
				System.out.println("user is not found");
			}

	}
	catch (Exception e) {
		e.printStackTrace();
	}
sc.close();
}
}
