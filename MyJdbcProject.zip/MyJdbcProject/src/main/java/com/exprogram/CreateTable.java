package com.exprogram;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class CreateTable {

	public static void main(String[] args) {
		String mytable="create table cloudemp(Cid int(4) primary key,Cname varchar(30))";
		
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/dkdatabase";
		String user="root";
		String password="root";
		
		try {
		Class.forName(driver);
		Connection conn=DriverManager.getConnection(url, user, password);
		Statement st=conn.createStatement();
		st.execute(mytable);
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
