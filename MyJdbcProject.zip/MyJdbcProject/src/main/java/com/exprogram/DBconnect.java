package com.exprogram;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;

public class DBconnect {

	public static void main(String[] args) {
		int student_id;
		String student_name;
		String student_mailid;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter student id");
		student_id=sc.nextInt();
		System.out.println("Enter student name");
		student_name=sc.next();
		System.out.println("Enter student mail id");
		student_mailid=sc.next();
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/dkdatabase";
		String username="root";
		String password="root";

		try {
			Class.forName(driver);
			Connection conn=DriverManager.getConnection(url, username, password);
			Statement st=conn.createStatement();
			String ins="insert into student values("+student_id+",'"+student_name+"','"+student_mailid+"')";
			int i=st.executeUpdate(ins);
			if(i>0) {
				System.out.println("Record inserted");
			}else {
				System.out.println("Not inserted");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		sc.close();
	}

}
