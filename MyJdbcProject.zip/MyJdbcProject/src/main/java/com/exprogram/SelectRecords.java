package com.exprogram;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class SelectRecords {

	public static void main(String[] args) {

		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/dkdatabase";
		String user="root";
		String password="root";
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;

		//Connection 

		try {
			Class.forName(driver);
			conn =DriverManager.getConnection(url, user, password);
			st=conn.createStatement();

			String sql="select * from product";
			rs=st.executeQuery(sql);
			System.out.println("ID\t\tPRODUCTNAME\tPRICE\t\tEXPIRY");
			while(rs.next()) {
				int product_id=rs.getInt(1);
				String product_name=rs.getString(2);
				float product_price=rs.getFloat(3);
				Date expiry_date=rs.getDate(4);
				System.out.println(product_id+"\t\t"+product_name+"\t\t"+product_price+"\t\t"+expiry_date);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}


	}


}

