package com.exprogram;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;

public class CreateAndInsert {

	public static void main(String[] args) {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/dkdatabase";
		String user="root";
		String password="root";
		Connection conn=null;
		Statement st=null;
		String name=null;
		int id=0;

		Scanner sc=new Scanner(System.in);
		String ins=null;

		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(url, user, password);
			st=conn.createStatement();

			while (true)
			{

				System.out.println("Enter name");
				name=sc.next();
				System.out.println("Enter id");
				id=sc.nextInt();
				ins="insert into empdetails values("+id+",'"+name+"')";
				int i=st.executeUpdate(ins);
				if(i>0) 
				{
					System.out.println("Record is inserted successfully");
				}
				else 
				{
					System.out.println("Not inserted");
				}

				System.out.println("Do you want to continue y/n");
				char ch=sc.next().charAt(0);
				if(ch=='n') {
					break;
				}

			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}	
		System.out.println("end of program");
	}
}



