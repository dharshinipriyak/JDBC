package com.java;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ATMOperation
{

	Scanner sc=new Scanner(System.in);
	static Connection conn=null;
	static ResultSet rs=null;
	static Statement st=null;
	DBConnect dbc;
	//constructor
	public ATMOperation() throws SQLException
	{
		//object
		DBConnect dbc=new DBConnect();
	}
	public void login_Customer() throws SQLException
	{
		conn=DBConnect.getConnection();
		System.out.println("\tPlease Enter Your\nPersonal Identification Number");
		String password=sc.next();
		int log=dbc.login(password);
		if (log>1)
		{
			System.out.println("Login Successfully");
			displayMenu();
			
		}
		else
		{
			System.out.println("X Login Failed X");
			login_Customer();
		}

	}
	private void displayMenu() throws SQLException
	{
		System.out.println("Welcome");
		System.out.println("*****Please Enter your Desired Option****");
		System.out.println("1.Check Balance\t2.Withdraw Cash\n3.Deposit Cash\t4.Exit");
		System.out.println("*****************************************");
		int option=sc.nextInt();
		switch(option)
		{
		case 1: check_Balance();
			break;
		case 2: withdraw_Money();
			break;
		case 3:	deposit_Money();
			break;
		case 4: exitatm();
			break;
		default:
			System.out.println("Please choose valid option");
			break;
		}
	}
	
	//call the function
	private void check_Balance() throws SQLException 
	{
		//using object to get balance
		int balance = dbc.getBalance(dbc.Customer_pin);
			System.out.println("Your Available Balanceis : "+balance);
			displayMenu();
	}
	
	private void withdraw_Money() throws SQLException 
	{
		System.out.println("Enter the Amount to Withdraw");
		int amount=sc.nextInt();
		if(amount%100==0) 
		{
		boolean flag=dbc.withdrawMoney(dbc.Customer_pin, amount);
		if(flag)
		{
			System.out.println("Please take Your cash "+amount);
			System.out.println("Amount withdraw successfully");
			displayMenu();
		}
		else
		{
			System.out.println("Insuficient Balance");
			displayMenu();
		}
		}
		else
		{
			System.out.println("Please Enter the Amount in Multiple of 100,200 and 500");
		}
	}
	private void deposit_Money() throws SQLException 
	{
	System.out.println("Enter the Amount to Deposit");
	int amount=sc.nextInt();
	boolean flag=dbc.depositMoney(dbc.Customer_pin, amount);
	if(flag)
	{
		System.out.println(amount+" Amount Deposited Successfully");
		displayMenu();
	}
		
	}
	private void exitatm()
	{
	System.out.println("Thank you for visiting out ATM");
	System.out.println("Please visit again");
	System.out.println("Have a nice Day :)");
		
	}
	public static void main(String[] args) throws SQLException 
	{
		//create object
		ATMOperation atm=new ATMOperation();
		atm.login_Customer();
		
	}
}
