package com.java;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.security.auth.login.LoginContext;

public class DBConnect 
{
	//Connection

	//variables
	static String driver="com.mysql.cj.jdbc.Driver";
	static String url="jdbc:mysql://localhost:3306/dkdatabase";
	static String un="root";
	static String pass="root";
	static Connection conn=null;
	static ResultSet rs=null;
	static Statement st=null;

	int Customer_pin=0;
	int Balance_Money=0;

	public static Connection getConnection()
		{
		try 
		{
			
			Class.forName(driver);
			conn=DriverManager.getConnection(url, un, pass);
			if(conn==null) 
			{
				System.out.println("Error in connection");
			}
			
		}
		catch(Exception e) 
		{
			System.out.println(e.getMessage());
		}
		return conn;
	}
	public int login(String password) throws SQLException
	{
		st=conn.createStatement();
		String sql="select * from customer where Customer_password='"+password+"'";
		rs=st.executeQuery(sql);
		if(rs.next())
		{
			Customer_pin=rs.getInt(Customer_pin);

		}
		else
		{
	System.out.println("Cannot login");
		}
		return Balance_Money;
	}
	public int getBalance(int id)throws SQLException
	{
		st=conn.createStatement();
		String sql=("select Balanceamount from Account where customer_pin="+id+"");
		rs=st.executeQuery(sql);
		if(rs.next())
		{
			Balance_Money=rs.getInt(Balance_Money);
		return Balance_Money;
		}
		else
		{
			return 0;
		}
	}
	public boolean withdrawMoney(int id,int amount) throws SQLException
	{
		st=conn.createStatement(); 
			if(amount>Balance_Money)
			{
				return false;
			}
			else
			{
				String sql=("update Amount set BalanceAmount="+(Balance_Money-amount)+"where Customer_pin="+id);
				st.executeUpdate(sql);
				return true;
			}
		
	}

	public boolean depositMoney(int id,int amount) throws SQLException
	{
		st=conn.createStatement();
			String sql=("update Amount set BalanceAmount="+(Balance_Money-amount)+"where Customer_pin="+id);
			int a=st.executeUpdate(sql);
			if(a==1)	
			{
				return true;
			}
			else
			{
			return false;
			}
	}
}
	
